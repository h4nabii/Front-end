how-to-pay.html 与 how-to-pay-2.html 的唯一区别是 navigator 的实现

pay 使用图片更还原效果
pay-2 使用文字和实现 hover 效果但缺少部分图像

两个文件共用一个 css，其中 pay-2 通过 id #__navi2 选择 navigator > ul